# Knowledge Assistant (RAG)

Semantische Dokumentensuche ueber PDFs, TXT und Markdown. Antworten mit
Quellenangabe (Datei + Seite) und automatischer Belegpruefung.

## Schnellstart (offline, ohne API-Key und ohne Modell-Download)

```bash
python -m venv .venv
source .venv/bin/activate            # Windows: .venv\Scripts\activate
pip install -r requirements.txt

python make_docs.py                                    # 3 Testdokumente
python tests/test_rag.py                               # 8 Unit-Tests
python cli.py --embedding hashing ingest docs --reset
python cli.py --embedding hashing ask "Was ist das Schluesselenzym des Calvin-Zyklus?" --llm extractive
streamlit run app.py
```

## Richtiger Betrieb (echte Embeddings + LLM)

```bash
cp .env.example .env                 # API-Key eintragen
python cli.py ingest docs --reset    # laedt beim ersten Lauf ~80 MB Modell
python cli.py ask "Warum ist Ueberlappung beim Chunking noetig?" --llm anthropic
```

Weitere Befehle:

```bash
python cli.py info                                   # Index-Status
python cli.py ask "..." --source calvin_zyklus.pdf   # Suche einschraenken
python cli.py ask "..." -k 8 --json                  # mehr Kontext, JSON-Ausgabe
```

## Architektur

```
loader.py      PDF/TXT/MD -> Seiten (Seitenzahl bleibt erhalten fuer Zitate)
chunking.py    Absatz- und satzbewusstes Chunking mit Ueberlappung
embeddings.py  default (MiniLM) | openai | hashing (offline)
store.py       ChromaDB, Cosine-Distanz, persistent
rag.py         Prompt, Generatoren, Zitatpruefung
pipeline.py    ingest() und ask()
```

## Chunking-Strategie

Zielgroesse 800 Zeichen, Ueberlappung 150. Absatzgrenzen werden respektiert;
ueberlange Absaetze werden an Satzenden geteilt, nie mitten im Wort. Chunks
kleiner als 100 Zeichen werden an den Vorgaenger angehaengt. Seiten werden nie
zusammengefuehrt, sonst waere die Seitenzahl im Zitat falsch.

Begruendung: ein Schnitt mitten im Satz zerstoert den Embedding-Kontext und
liefert Treffer, die als Zitat unbrauchbar sind. Ohne Ueberlappung waere eine
Antwort, die genau auf einer Grenze liegt, in keinem Chunk vollstaendig.

**Die Werte sind ein Startpunkt, keine gemessene Optimierung.** Siehe Grenzen.

## Massnahmen gegen Halluzination

1. Der Systemprompt verbietet Vorwissen und schreibt eine feste Ablehnungsformel
   vor, wenn der Kontext nicht ausreicht.
2. Jede Aussage muss mit `[n]` belegt werden.
3. `check_grounding()` prueft nach der Generierung, ob die zitierten Nummern
   existieren und ob ueberhaupt zitiert wurde. Verstoesse werden als Warnung
   ausgegeben und `grounded=False` gesetzt.
4. Ein Relevanz-Schwellwert (0.15) verhindert, dass irrelevante Chunks als
   Kontext durchgereicht werden — ohne ihn beantwortet das Modell auch Fragen,
   zu denen nichts im Index steht.
5. Die UI zeigt jeden abgerufenen Chunk im Volltext und markiert, welche
   tatsaechlich zitiert wurden. Damit ist jede Antwort manuell nachpruefbar.

## Bekannte Grenzen

- **`hashing` ist kein semantisches Embedding.** Es ist gewichtete
  Wortueberlappung. Es findet "Chloroplasten", wenn "Chloroplasten" in der Frage
  steht, aber nicht bei "Wo sitzt die Photosynthese in der Zelle?". Zweck: die
  Pipeline ohne Download und ohne API-Kosten testbar machen. Fuer echte Nutzung
  `--embedding default`.
- **`extractive` ist kein LLM.** Es waehlt Saetze mit hoher Wortueberlappung und
  gibt sie woertlich aus. Es erfindet per Konstruktion nichts, formuliert aber
  auch nicht und kann nicht synthetisieren. Baseline, kein Produkt.
- **Der Schwellwert 0.15 ist gesetzt, nicht gemessen.** Er unterscheidet sich je
  nach Embedding-Backend. Kalibrierung wuerde bedeuten: 30–50 Fragen mit
  bekannter Antwort und bekannten Nicht-Antworten sammeln, Precision/Recall des
  Retrieval gegen den Schwellwert plotten.
- **Die Zitatpruefung prueft Form, nicht Inhalt.** Sie verifiziert, dass `[2]`
  existiert — nicht, dass Chunk 2 die Aussage wirklich stuetzt. Das ist der
  offene Punkt. Naechster Schritt waere ein Entailment-Check pro Satz.
- **Kein Reranking, kein Hybrid-Retrieval.** Reines Dense-Retrieval. BM25 als
  zweiter Kanal wuerde exakte Begriffe und Zahlen deutlich besser treffen.
- **Kein OCR.** Gescannte PDFs ohne Textlayer werden mit klarer Meldung
  abgelehnt.
- **Getestet gegen 3 synthetische Dokumente.** Das belegt, dass die Pipeline
  laeuft — nicht, wie gut sie ist.

## Testabdeckung

`tests/test_rag.py` prueft: Chunk-Groessen, Ueberlappung, Seitentrennung,
Erkennung erfundener Zitatnummern, Erkennung fehlender Belege, Ablehnung bei
irrelevantem Kontext, sowie einen vollstaendigen Durchlauf
ingest -> retrieve -> answer gegen eine echte ChromaDB-Instanz.
