import time
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional

from .chunking import chunk_pages
from .embeddings import get_backend, EmbeddingBackend
from .loader import load_dir, load_file
from .rag import (Answer, Generator, build_context, check_grounding,
                  get_generator, NO_ANSWER)
from .store import VectorStore

MIN_SCORE = 0.15   # unterhalb dessen gilt ein Treffer als irrelevant


@dataclass
class IngestReport:
    files: int
    pages: int
    chunks: int
    errors: List[str]
    duration_s: float


def ingest(path, store: VectorStore, reset: bool = False) -> IngestReport:
    t0 = time.time()
    if reset:
        store.reset()

    p = Path(path)
    errors = []
    pages = []
    files = 0

    if p.is_dir():
        for f in sorted(p.iterdir()):
            if f.suffix.lower() not in {".pdf", ".txt", ".md"}:
                continue
            files += 1
            try:
                pages.extend(load_file(f))
            except Exception as e:
                errors.append(str(e))
    else:
        files = 1
        try:
            pages.extend(load_file(p))
        except Exception as e:
            errors.append(str(e))

    chunks = chunk_pages(pages)
    store.add(chunks)
    return IngestReport(files, len(pages), len(chunks), errors, time.time() - t0)


def ask(question: str, store: VectorStore, generator: Generator,
        k: int = 5, source: Optional[str] = None,
        min_score: float = MIN_SCORE) -> Answer:
    hits = store.search(question, k=k, source=source)
    relevant = [h for h in hits if h.score >= min_score]

    if not relevant:
        warn = [] if hits else ["Index ist leer oder Filter ergab nichts."]
        if hits:
            warn.append(
                f"Kein Treffer ueber Schwellwert {min_score} "
                f"(bester: {hits[0].score})."
            )
        return Answer(question, NO_ANSWER, hits, [], warn, True)

    context = build_context(relevant)
    try:
        text = generator.generate(question, context)
    except Exception as e:
        return Answer(question, f"Generierungsfehler: {e}", relevant, [],
                      [str(e)], False)

    cited, warnings, grounded = check_grounding(text, relevant)
    return Answer(question, text, relevant, cited, warnings, grounded)


def build_store(embedding: str = None, persist_dir: str = "chroma_db",
                **kw) -> VectorStore:
    backend: EmbeddingBackend = get_backend(embedding, **kw)
    return VectorStore(backend, persist_dir)
